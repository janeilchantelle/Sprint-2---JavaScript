// JavaScript to display Vegan Recipes from JSON file to HTML.

// Function to format ingredients as a comma-separated string.

function getIngredientsString(ingredients) {
    return ingredients.join(', ');
}

// Function to format instructions with numbered steps.


function getInstructionsNumbered(instructions) {
    return instructions.replace(/(\d+\.\s*)/g, '<br>$1');
}

// Function to format the recipe title.

function getRecipeTitle(title) {
    return `<h2 class="recipe-title">${title}</h2>`;
}

// Function to format the recipe summary.

function getRecipeSummary(summary) {
    return `<p class="recipe-summary">${summary}</p>`;
}

// Fetch JSON data and display recipes on the webpage.

fetch('VeganRecipes.json')
    .then(response => response.json())
    .then(data => {

        data.forEach(record => {
            const recipeContainer = document.createElement('div');
            recipeContainer.className = 'recipe-container';

            recipeContainer.innerHTML = `
                ${getRecipeTitle(record['Title'])}
                ${getRecipeSummary(record['Recipe'])}
                <p><strong>Ingredients:</strong> ${getIngredientsString(record['Ingredients'])}</p>
                <ol><strong>Instructions:</strong><br>${getInstructionsNumbered(record['Instructions'])}</ol>
            `;

            document.body.appendChild(recipeContainer);

            // Display JSON data to the console.

            console.log('Title:', record['Title']);
            console.log('Recipe:', record['Recipe']);
            console.log('Ingredients:', getIngredientsString(record['Ingredients']));
            console.log('Instructions:', record['Instructions']);
            console.log('');
        });
    })
    .catch(error => console.error('Error reading JSON data:', error));
